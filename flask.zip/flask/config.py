import os
URL_DB = "mongodb+srv://quanchopper1234:1234@cluster0.mrj9rx8.mongodb.net/?retryWrites=true&w=majority"
BATCH_SIZE = 20
LEN_CACHE = 20000
TIME_SLEEP = 0.1
TIME_SLEEP_CHECK_PREDICT = 0.01
TIME_MODEL = 0.5
THREAD = 2 - 1
NUM_PROCESS = 2